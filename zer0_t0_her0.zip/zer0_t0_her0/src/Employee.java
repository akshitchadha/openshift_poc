import java.util.List;

public class Employee {
    String name;

    private Designation designation;

    private Unit unit;



    private Integer experience_in_years;

    private List<Skill>  skills;

    public Employee(String name, Designation designation, Unit unit, Integer experience_in_years, List<Skill> skills) {
        this.name = name;
        this.designation = designation;
        this.unit = unit;
        this.experience_in_years = experience_in_years;
        this.skills = skills;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Designation getDesignation() {
        return designation;
    }

    public void setDesignation(Designation designation) {
        this.designation = designation;
    }

    public Unit getUnit() {
        return unit;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }


    public Integer getExperience_in_years() {
        return experience_in_years;
    }

    public void setExperience_in_years(Integer experience_in_years) {
        this.experience_in_years = experience_in_years;
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", designation=" + designation +
                ", unit=" + unit +
                ", experience_in_years=" + experience_in_years +
                ", skills=" + skills +
                '}';
    }
}
