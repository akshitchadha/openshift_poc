public enum Skill {
    JAVA,
    MICROSOFT,
    PYTHON,
    JAVASCRIPT,
    NODE,
    SPRING,
    PMP,
    DESIGN,
    JPA,
    ANGULAR
}
