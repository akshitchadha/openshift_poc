import java.util.ArrayList;
import java.util.List;

public class EmployeesTest {
    private static final List<Employee> employees = new ArrayList<>();

    public static void main(String[] args) {

        intialise();

        System.out.println("-----All in EDC----");
        System.out.println(getAllEmployeeinunit(Unit.EDC));



        System.out.println("-----All in FS----");
        System.out.println(getAllEmployeeinunit(Unit.FS));

        System.out.println("-----All with Skill as Java----");
        System.out.println(getAllEmployeeWithSkill(Skill.JAVA));

        System.out.println("-----All with  10 years of experience----");
        System.out.println(getAllSeniorEployee(10));



    }

    private static void intialise() {

        List<Skill> dev1Skills = new ArrayList<>();
        dev1Skills.add(Skill.JAVA);
        dev1Skills.add(Skill.JPA);

        employees.add(new Employee("Amit", Designation.DEVELOPER, Unit.EDC, 8, dev1Skills));


        List<Skill> dev2Skills = new ArrayList<>();
        dev2Skills.add(Skill.MICROSOFT);
        employees.add(new Employee("Rahul", Designation.DEVELOPER, Unit.EDC, 5, dev2Skills));


        List<Skill> dev3Skills = new ArrayList<>();
        dev3Skills.add(Skill.PYTHON);
        employees.add(new Employee("Peter", Designation.DEVELOPER, Unit.FS, 7, dev3Skills));


        List<Skill> dev4Skills = new ArrayList<>();
        dev4Skills.add(Skill.ANGULAR);
        dev4Skills.add(Skill.JAVASCRIPT);
        employees.add(new Employee("Stanley", Designation.DEVELOPER, Unit.OIL_GAS, 3, dev4Skills));


        List<Skill> dev5Skills = new ArrayList<>();
        dev5Skills.add(Skill.ANGULAR);
        dev5Skills.add(Skill.JAVASCRIPT);
        employees.add(new Employee("Manoj", Designation.DEVELOPER, Unit.FS, 3, dev5Skills));


        List<Skill> managerSkills = new ArrayList<>();
        managerSkills.add(Skill.PMP);
        employees.add(new Employee("Jose", Designation.MANAGER, Unit.EDC, 15, managerSkills));


        List<Skill> architectSkills = new ArrayList<>();
        architectSkills.add(Skill.DESIGN);
        employees.add(new Employee("Pirlo", Designation.ARCHITECT, Unit.EDC, 13, architectSkills));

    }



    public static List<Employee> getAllEmployeeinunit(Unit unit) {
        List<Employee> employeeInEDC = new ArrayList<>();
        for (Employee employee : employees) {
            if (employee.getUnit() == unit) {
                employeeInEDC.add(employee);
            }
        }
        return employeeInEDC;
    }



    public static List<Employee> getAllEmployeeWithSkill(Skill skill) {
        List<Employee> employeeWithSkill = new ArrayList<>();
        for (Employee employee : employees) {
            if (employee.getSkills().contains(skill)) {
                employeeWithSkill.add(employee);
            }
        }
        return employeeWithSkill;
    }


    public static List<Employee> getAllSeniorEployee( Integer years_of_experience) {
        List<Employee> employeeWithSkill = new ArrayList<>();
        for (Employee employee : employees) {
            if (employee.getExperience_in_years() > years_of_experience) {
                employeeWithSkill.add(employee);
            }
        }
        return employeeWithSkill;
    }




}

